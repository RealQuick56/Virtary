from PyQt5 import QtCore, QtGui, QtWidgets, uic, QtMultimedia
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon, QKeyEvent
from PyQt5.Qt import *
import random
import sqlite3
import threading

con = sqlite3.connect('questions.sqlite')
cur = con.cursor()

con_1 = sqlite3.connect('players_balls.sqlite')
cur_1 = con_1.cursor()

g = False

class MyWidget(QtWidgets.QWidget):
    def __init__(self, balls, quantity, correct_answers, prompts, used_ques, bools):
        super().__init__()
        self.balls = balls
        self.quantity = quantity
        self.used = used_ques
        self.correct_answers = correct_answers
        self.prompts = prompts
        self.incorrect = ''
        self.bools = bools
        uic.loadUi('projectWidget.ui', self)
        self.pushButton.clicked.connect(self.add_players)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_Enter:
            self.add_players()

    def add_players(self):
        global g
        name = self.lineEdit.text()
        date = self.dateEdit.text()
        if self.bools:
            self.incorrect = len(self.used) - self.correct_answers
        else:
            self.incorrect = len(self.used) - self.correct_answers - 1
        if name == '':
            QMessageBox.warning(self, 'Не введено значение', 'Не введен никнейм,'
                                                                 ' пожалуйста, введите значение', QMessageBox.Ok)
        else:
            que = "INSERT INTO players(name, score, date, correct_answers, number_of_prompt, count_of_incorrect)" \
                  " VALUES(" + f"\'{name}\', {int(self.balls)}, \'{date}\'," \
                f" {self.correct_answers}, {self.prompts}, {self.incorrect})"
            cur_1.execute(que)
            con_1.commit()
            con_1.close()
            con.close()
            self.close()
            g = True


class Widget(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('widgetinfoproject.ui', self)
        fname = open('print.txt', mode='r').read()
        self.setWindowIcon(QIcon('Quiz.jpg'))
        self.label.setText(fname)


class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('project_newVar_3.ui', self)
        self.player_timer()

        self.centralwidget.setObjectName("centralwidget")

        self.label.setGeometry(QtCore.QRect(160, 20, 641, 201))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setObjectName("label")

        self.pushStart.setGeometry(QtCore.QRect(380, 270, 201, 51))
        self.pushStart.setObjectName("pushButton")

        self.pushAnswer.setGeometry(QtCore.QRect(420, 380, 121, 41))
        self.pushAnswer.setObjectName("pushButton_2")

        self.pushInfo.setGeometry(QtCore.QRect(10, 20, 131, 28))
        self.pushInfo.setObjectName("pushButton_3")

        self.radioButton.setGeometry(QtCore.QRect(140, 240, 211, 51))
        self.radioButton.setObjectName("radioButton")

        self.radioButton_2.setGeometry(QtCore.QRect(140, 310, 221, 51))
        self.radioButton_2.setObjectName("radioButton_2")

        self.radioButton_3.setGeometry(QtCore.QRect(690, 240, 271, 41))
        self.radioButton_3.setObjectName("radioButton_3")

        self.radioButton_4.setGeometry(QtCore.QRect(690, 310, 281, 41))
        self.radioButton_4.setObjectName("radioButton_4")

        self.label_3.setGeometry(QtCore.QRect(80, 450, 181, 31))
        self.label_3.setObjectName("label_3")

        self.button_exit.setGeometry(QtCore.QRect(790, 440, 41, 41))
        self.button_exit.setObjectName("button_exit")

        self.label_answer.setGeometry(QtCore.QRect(320, 230, 331, 31))
        font = QtGui.QFont()
        font.setFamily("MS Sans Serif")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_answer.setFont(font)
        self.label_answer.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label_answer.setText("")
        self.label_answer.setAlignment(QtCore.Qt.AlignCenter)
        self.label_answer.setObjectName("label_answer")

        self.button_prompt.setGeometry(QtCore.QRect(840, 440, 41, 41))
        self.button_prompt.setObjectName("button_prompt")

        self.horizontalSlider.setGeometry(QtCore.QRect(830, 20, 131, 22))
        self.horizontalSlider.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider.setObjectName("horizontalSlider")


        self.statusbar.setObjectName("statusbar")

        self.centralwidget.setStyleSheet("""
                                                 background-color: #00b3cf; """)

        self.button_exit.setIcon(QIcon('59801.png'))

        self.label.setAlignment(Qt.AlignAbsolute)
        self.label.setWordWrap(True)
        self.label.setStyleSheet("""background-color: #ffa1a1;
                                                    color: black;
                                                    border-radius: 4px;""")
        self.pushStart.setStyleSheet("""border-radius: 4px;
                                                 background-color: #af5fed;
                                                 border: 1px solid black""")
        self.pushAnswer.setStyleSheet("""border-radius: 4px;
                                                         background-color: #af5fed;
                                                         border: 1px solid black""")
        self.button_exit.setStyleSheet("""border-radius: 4px;
                                                         background-color: #af5fed;
                                                         border: 1px solid black""")
        self.button_prompt.setStyleSheet("""border-radius: 4px;
                                                         background-color: #af5fed;
                                                         border: 1px solid black""")


        self.group = QtWidgets.QButtonGroup()
        self.group.addButton(self.radioButton)
        self.group.addButton(self.radioButton_2)
        self.group.addButton(self.radioButton_3)
        self.group.addButton(self.radioButton_4)

        self.pushStart.clicked.connect(self.start_virtory)
        self.pushAnswer.clicked.connect(self.answer)
        self.button_exit.clicked.connect(self.end)
        self.radioButton.hide()
        self.radioButton_2.hide()
        self.radioButton_3.hide()
        self.radioButton_4.hide()
        self.pushAnswer.hide()
        self.label_3.hide()
        self.button_prompt.hide()
        self.button_exit.hide()
        self.pushInfo.clicked.connect(self.info)


        self.button_prompt.setIcon(QIcon('OIP.jpg'))
        self.button_prompt.clicked.connect(self.prompt)

        self.horizontalSlider.valueChanged.connect(self.change)
        self.player.setVolume(0)

        self.progressBar.hide()
        self.progressBar.setValue(0)
        self.lcdNumber.hide()
        self.balls = 0
        self.used_ques = []
        self.correct_answer = ''
        self.bool = False
        self.start_number = 0
        self.count_of_right_answers = 0
        self.count_of_prompt = 0
        self.count_of_sec = 0



        _translate = QtCore.QCoreApplication.translate
        self.label.setText(_translate("MainWindow", "Добро пожаловать в викторину знатоков!"))
        self.pushStart.setText(_translate("MainWindow", "Начать играть"))
        self.pushAnswer.setText(_translate("MainWindow", "Ответить"))
        self.radioButton.setText(_translate("MainWindow", "RadioButton"))
        self.radioButton_2.setText(_translate("MainWindow", "RadioButton"))
        self.radioButton_3.setText(_translate("MainWindow", "RadioButton"))
        self.radioButton_4.setText(_translate("MainWindow", "RadioButton"))
        self.label_3.setText(_translate("MainWindow", "Количество баллов:"))
        self.button_exit.setText(_translate("MainWindow", ""))
        self.button_prompt.setText(_translate("MainWindow", ""))
        self.pushInfo.setText(_translate("MainWindow", "Об игре"))

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_Q:
            self.Timer.cancel()
            self.answer()
        elif int(event.key()) + 1 == Qt.Key_Enter:
            self.start_virtory()
        elif event.key() == Qt.Key_1:
            self.radioButton.setChecked(True)
        elif event.key() == Qt.Key_2:
            self.radioButton_2.setChecked(True)
        elif event.key() == Qt.Key_3:
            self.radioButton_3.setChecked(True)
        elif event.key() == Qt.Key_4:
            self.radioButton_4.setChecked(True)
        elif event.key() == Qt.Key_Escape:
            self.end()
        elif event.key() == Qt.Key_W:
            self.prompt()

    def closeEvent(self, event: QCloseEvent):
        valid = QMessageBox.question(self, 'Выход', 'Вы точно хотите выйти? Результат не будет сохранен!',
                                     QMessageBox.Yes, QMessageBox.No)
        if valid == QMessageBox.Yes:
            self.Timer.cancel()
            self.Timer_2.cancel()
            self.player.stop()
            con_1.close()
            con.close()
            event.accept()
        elif valid == QMessageBox.No:
            event.ignore()

    def question(self):
        self.lcdNumber.show()
        self.progressBar.show()
        self.label_answer.clear()
        s = 1
        g = True
        self.quantity = len(cur.execute("""SELECT * FROM virtory""").fetchall())
        self.steps = 100 // self.quantity
        while g:
            s = random.randint(1, self.quantity)
            if s in self.used_ques:
                g = True
            else:
                g = False
        self.used_ques.append(s)
        self.progressBar.setValue((len(self.used_ques) - 1) * self.steps)
        if self.quantity - len(self.used_ques) == 0:
            self.bool = True
        result = cur.execute("""SELECT questions, answer_1, answer_2, answer_3, answer_4 FROM virtory
                                WHERE id = ?""", (s,)).fetchone()

        self.correct_answer = result[1]
        question = result[0]
        answer_1 = result[1]
        answer_2 = result[2]
        answer_3 = result[3]
        answer_4 = result[4]
        self.list_of_result = [answer_1, answer_2, answer_3, answer_4]
        self.list_of_result = random.sample(self.list_of_result, len(self.list_of_result))
        self.label.setText(question)
        self.radioButton.setText(self.list_of_result[0])
        self.radioButton_2.setText(self.list_of_result[1])
        self.radioButton_3.setText(self.list_of_result[2])
        self.radioButton_4.setText(self.list_of_result[3])

    def start_virtory(self):
        if self.start_number == 0:  # Здесь реализовано начало самой игры
            valid = QMessageBox.information(self, 'Правила игры', 'Приветствуем в нашей викторине!'
                                                                        ' Правила очень просты:'
                                                                        ' Дано 30 секунд на ответ (Не успел,'
                                                                        ' значит опоздал).'
                                                                        ' За правильный ответ даеться 1 балл'
                                                                        ' (за неправильный - 0).'
                                                                        ' Вы можете выбирать ответы кнопками 1-4,'
                                                                        ' отвечать на кнопку Q (только QWERTY. раскладка)'
                                                                        ' и переход на кнопку Enter'
                                                                        ' подсказка на кнопку W и esc для выхода.'
                                                                        ' Желаем вам удачи!', QMessageBox.Ok)
            if valid == QMessageBox.Ok:
                self.timer()
                self.group.setExclusive(False)
                self.radioButton.setChecked(False)
                self.radioButton_2.setChecked(False)
                self.radioButton_3.setChecked(False)
                self.radioButton_4.setChecked(False)
                self.group.setExclusive(True)
                self.radioButton.setEnabled(True)
                self.radioButton_2.setEnabled(True)
                self.radioButton_3.setEnabled(True)
                self.radioButton_4.setEnabled(True)
                self.pushAnswer.show()
                self.pushAnswer.setEnabled(True)
                self.pushStart.hide()
                self.radioButton.show()
                self.radioButton_2.show()
                self.radioButton_3.show()
                self.radioButton_4.show()
                self.label_3.show()
                self.label_3.setText(f'Количество баллов: {self.balls}')
                self.button_prompt.show()
                self.button_exit.show()
                self.question()
                self.start_number += 1
        else:
            self.timer()
            self.group.setExclusive(False)
            self.radioButton.setChecked(False)
            self.radioButton_2.setChecked(False)
            self.radioButton_3.setChecked(False)
            self.radioButton_4.setChecked(False)
            self.group.setExclusive(True)
            self.radioButton.setEnabled(True)
            self.radioButton_2.setEnabled(True)
            self.radioButton_3.setEnabled(True)
            self.radioButton_4.setEnabled(True)
            self.pushAnswer.show()
            self.pushAnswer.setEnabled(True)
            self.pushStart.hide()
            self.radioButton.show()
            self.radioButton_2.show()
            self.radioButton_3.show()
            self.radioButton_4.show()
            self.label_3.show()
            self.label_3.setText(f'Количество баллов: {self.balls}')
            self.question()

    def answer(self):  # В этой функции реализован выбор правильного ответа
        if self.bool:
            if self.radioButton.isChecked() and self.radioButton.text() == self.correct_answer:
                self.balls += 1
                self.label_answer.setText('Правильно!')
                self.count_of_right_answers += 1
                self.progressBar.setValue(len(self.used_ques) * self.steps + self.steps)
                valid = QMessageBox.information(self, 'Конец игры', 'Поздравляем, мы ответели на все вопросы!'
                                                                          ' Сохраняем результат',
                                                QMessageBox.Ok)
                if valid == QMessageBox.Ok:
                    self.widget = MyWidget(self.balls, self.quantity, self.count_of_right_answers, self.count_of_prompt,
                                           self.used_ques, self.bool)
                    self.widget.setWindowTitle('Сохранение результата')
                    self.widget.show()
            elif self.radioButton_2.isChecked() and self.radioButton_2.text() == self.correct_answer:
                self.balls += 1
                self.label_answer.setText('Правильно!')
                self.count_of_right_answers += 1
                self.progressBar.setValue(len(self.used_ques) * self.steps + self.steps)
                valid = QMessageBox.information(self, 'Конец игры', 'Поздравляем, мы ответели на все вопросы!'
                                                                          ' Хотите сохранить результат?',
                                                QMessageBox.Ok)
                if valid == QMessageBox.Ok:
                    self.widget = MyWidget(self.balls, self.quantity, self.count_of_right_answers, self.count_of_prompt,
                                           self.used_ques, self.bool)
                    self.widget.setWindowTitle('Сохранение результата')
                    self.widget.show()
            elif self.radioButton_3.isChecked() and self.radioButton_3.text() == self.correct_answer:
                self.balls += 1
                self.label_answer.setText('Правильно!')
                self.count_of_right_answers += 1
                self.progressBar.setValue(len(self.used_ques) * self.steps + self.steps)
                valid = QMessageBox.information(self, 'Конец игры', 'Поздравляем, мы ответели на все вопросы!'
                                                                          ' Хотите сохранить результат?',
                                                QMessageBox.Ok)
                if valid == QMessageBox.Ok:
                    self.widget = MyWidget(self.balls, self.quantity, self.count_of_right_answers, self.count_of_prompt,
                                           self.used_ques, self.bool)
                    self.widget.setWindowTitle('Сохранение результата')
                    self.widget.show()
            elif self.radioButton_4.isChecked() and self.radioButton_4.text() == self.correct_answer:
                self.label_answer.setText('Правильно!')
                self.count_of_right_answers += 1
                self.balls += 1
                self.progressBar.setValue(len(self.used_ques) * self.steps + self.steps)
                valid = QMessageBox.information(self, 'Конец игры', 'Поздравляем, мы ответели на все вопросы!'
                                                                          ' Хотите сохранить результат?',
                                                QMessageBox.Ok)
                if valid == QMessageBox.Ok:
                    self.widget = MyWidget(self.balls, self.quantity, self.count_of_right_answers, self.count_of_prompt,
                                           self.used_ques, self.bool)
                    self.widget.setWindowTitle('Сохранение результата')
                    self.widget.show()
            elif (self.radioButton.isChecked() and self.radioButton.text() != self.correct_answer or
                  self.radioButton_2.isChecked() and self.radioButton_2.text() != self.correct_answer or
                  self.radioButton_3.isChecked() and self.radioButton_3.text() != self.correct_answer or
                  self.radioButton_4.isChecked() and self.radioButton_4.text() != self.correct_answer):
                self.label_answer.setText('Неправильно!')
                self.progressBar.setValue(len(self.used_ques) * self.steps + self.steps)
                valid = QMessageBox.information(self, 'Конец игры', 'Поздравляем, мы ответели на все вопросы!'
                                                                          ' Хотите сохранить результат?',
                                                QMessageBox.Ok)
                if valid == QMessageBox.Ok:
                    self.widget = MyWidget(self.balls, self.quantity, self.count_of_right_answers, self.count_of_prompt,
                                           self.used_ques, self.bool)
                    self.widget.setWindowTitle('Сохранение результата')
                    self.widget.show()
            else:
                QMessageBox.warning(self, 'Не выбрано значение', 'Пожалуйста, будьте добры,'
                                                                       ' выберете один из вариантов ответа',
                                    QMessageBox.Ok)
        else:
            if self.radioButton.isChecked() and self.radioButton.text() == self.correct_answer:
                self.pushStart.show()
                self.pushStart.setText('Продолжить?')
                self.label_answer.setText('Правильно!')
                self.balls += 1
                self.count_of_right_answers += 1
                self.Timer.cancel()
                self.count_of_sec = 0
                self.lcdNumber.display(self.count_of_sec)
            elif self.radioButton_2.isChecked() and self.radioButton_2.text() == self.correct_answer:
                self.pushStart.show()
                self.pushStart.setText('Продолжить?')
                self.label_answer.setText('Правильно!')
                self.balls += 1
                self.count_of_right_answers += 1
                self.Timer.cancel()
                self.count_of_sec = 0
                self.lcdNumber.display(self.count_of_sec)
            elif self.radioButton_3.isChecked() and self.radioButton_3.text() == self.correct_answer:
                self.pushStart.show()
                self.pushStart.setText('Продолжить?')
                self.label_answer.setText('Правильно!')
                self.balls += 1
                self.count_of_right_answers += 1
                self.Timer.cancel()
                self.count_of_sec = 0
                self.lcdNumber.display(self.count_of_sec)
            elif self.radioButton_4.isChecked() and self.radioButton_4.text() == self.correct_answer:
                self.pushStart.show()
                self.pushStart.setText('Продолжить?')
                self.label_answer.setText('Правильно!')
                self.balls += 1
                self.count_of_right_answers += 1
                self.Timer.cancel()
                self.count_of_sec = 0
                self.lcdNumber.display(self.count_of_sec)
            elif (self.radioButton.isChecked() and self.radioButton.text() != self.correct_answer or
                  self.radioButton_2.isChecked() and self.radioButton_2.text() != self.correct_answer or
                  self.radioButton_3.isChecked() and self.radioButton_3.text() != self.correct_answer or
                  self.radioButton_4.isChecked() and self.radioButton_4.text() != self.correct_answer):
                self.pushStart.show()
                self.pushStart.setText('Продолжить?')
                self.label_answer.setText('НеПравильно!')
                self.Timer.cancel()
                self.count_of_sec = 0
                self.lcdNumber.display(self.count_of_sec)
            else:
                QMessageBox.warning(self, 'Не выбрано значение', 'Пожалуйста, будьте добры,'
                                                                       ' выберете один из вариантов ответа',
                                    QMessageBox.Ok)
                self.timer()

    def end(self):
        self.Timer.cancel()
        valid = QMessageBox.question(self, 'Вопрос',
                                     'Вы уверены, что хотите закончить?\nВаши данные будут сохранены в любом случае',
                                     QMessageBox.Yes, QMessageBox.No)
        if valid == QMessageBox.Yes:
            self.widget = MyWidget(self.balls, self.quantity, self.count_of_right_answers, self.count_of_prompt,
                              self.used_ques, self.bool)
            self.widget.setWindowTitle('Сохранение результата')
            self.widget.show()
            self.close()
        elif valid == QMessageBox.No:
            self.timer()

    def info(self):
        self.infowidget = Widget()
        self.infowidget.setWindowTitle('Об игре')
        self.infowidget.show()

    def timeout(self):
        self.pushStart.show()
        self.pushStart.setText('Продолжить?')
        self.radioButton.setDisabled(True)
        self.radioButton_2.setDisabled(True)
        self.radioButton_3.setDisabled(True)
        self.radioButton_4.setDisabled(True)
        self.pushAnswer.setDisabled(True)
        self.label_answer.setText('Вы не успели!')

    def timein(self):
        self.count_of_sec += 1
        self.lcdNumber.display(int(self.count_of_sec))
        if self.count_of_sec == 30:
            self.timeout()
            self.count_of_sec = 0
            self.lcdNumber.display(self.count_of_sec)
        else:
            self.timer()

    def change(self):
        self.horizontalSlider.setValue(self.horizontalSlider.value())
        self.player.setVolume(self.horizontalSlider.value())

    def timer(self):
        self.Timer = threading.Timer(1, self.timein)  # Тут реализована работа таймера, по истечению которого будет
        self.Timer.start()

    def prompt(self):
        valid = QMessageBox.question(MainWindow, 'Использование подсказки', 'Вы точно хотите использовать подсказку?'
                                                                            ' Цена подсказки - 5 баллов',
                                     QMessageBox.Ok)
        if valid == QMessageBox.Ok and self.balls >= 5:
            self.balls -= 5
            self.count_of_prompt += 1
            s = self.list_of_result.index(self.correct_answer)
            QMessageBox.information(MainWindow, 'Использование подсказки', f'Правильный ответ: {self.list_of_result[s]}'
                                    , QMessageBox.Ok)
        elif valid == QMessageBox.Ok and self.balls <= 5:
            QMessageBox.warning(MainWindow, 'Недоступность операции', 'У вас не хватает баллов(', QMessageBox.Ok)
            pass

    def timer_in_timer(self):
        if self.player.stop() == None:
            self.player_timer()

    def player_timer(self):
        self.Timer_2 = threading.Timer(240, self.timer_in_timer)
        self.url = QtCore.QUrl.fromLocalFile("play.mp3")
        self.content = QtMultimedia.QMediaContent(self.url)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(self.content)
        self.player.play()
        self.Timer_2.start()



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.show()
    sys.exit(app.exec_())

